<?php 
	include_once("links.php");
	
	$menu = array(
		"Home" => $ROOT,
		"Progress" => $PROGRESS,
		"Demo" => $DEMO,
		"How To" => $HOW_TO,
		"Download" => $DOWNLOAD,
		"Index" => $INDEX,
		"Editor" => $EDITOR,
		"Upload" => $UPLOAD,
		"Setup" => $SETUP
	);
?>