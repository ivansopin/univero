<?php 
	header("Location: index");
	return;
?>