<?php
	session_start();
	
	include_once("../components/php/links.php");
	  
	if (!isset($_SESSION["logged"])) {
		header("Location: ".$LOGIN."/");
		return;
	}
	
	include_once("../components/php/ui.php");
	
	doHeader("Index", false);
?>

	<table class="collapsed websiteTable">
		<tr>
			<td class="top">
				<img src="<?php echo $PICS; ?>/logo.png" alt="logo" />
			</td>
			
			<td class="top leftPadding">
				<div class="subtitle">Quick Tips</div>
			
				<script type="text/javascript" src="<?php echo $JS."/service.js"; ?>"></script>
			
				<ul>				
					<li>
						Use the <span class="italic">Status</span> section on this page for a brief summary of the system's configuration.
					</li>
					
					<li>
						The <span class="bold">univero</span> project Web site: <a href="<?php echo $UNIVERO; ?>"><?php echo $UNIVERO; ?></a>.
					</li>
					
					<li>
						Before using <span class="bold">univero</span> for the first time, read the <a href="<?php echo $UNIVERO."/howto"; ?>">How To</a> section from the Web site.
					</li>
					
					<li>
						For feedback and support, email <script type="text/javascript">eSend();</script>.
					</li>
				</ul>
			</td>
		</tr>
	</table>
	
	<br />
	
	<table class="collapsed websiteTable">
		<tr>
			<td class="top">
				<div class="subtitle">Status</div>

				<p>
					This section will show whether everything is supported, such as SQLite access, database statistics, JavaScript, and so on. 
				</p>
			</td>
		</tr>
	</table>

<?php
	doFooter();
?>