<?php 
	include_once("links.php");

	$menu = array(
		"Index" => $INDEX,
		"Editor" => $EDITOR,
		"Upload" => $UPLOAD,
		"Setup" => $SETUP
	);
?>