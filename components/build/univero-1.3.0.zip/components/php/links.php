<?php 
	include_once("settings.php");

	$COMPONENTS = $ROOT.'/components'; 
	
	$JS = $COMPONENTS.'/js';
	$CSS = $COMPONENTS.'/css';
	$PICS = $COMPONENTS.'/pics';
	$DB = $COMPONENTS.'/db';
	$PHP_DIR = $COMPONENTS.'/php';
	$BUILD = $COMPONENTS.'/build';

	$PROGRESS = $ROOT.'/progress';
	$DEMO = $ROOT.'/demo';
	$HOW_TO = $ROOT.'/howto';
	$DOWNLOAD = $ROOT.'/download';
	
	$INDEX = $ROOT.'/index';  
	$EDITOR = $ROOT.'/editor';
	$LOGIN = $ROOT.'/login';
	$UPLOAD = $ROOT.'/upload';
	
	$CONFIGURE = $PHP_DIR.'/configure.php';
	
	$UNIVERO = 'http://ivansopin.atbhost.net/univero';
?>